<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="flex justify-between align-center mt-10">

        <h2 class="intro-y text-lg font-medium"><?php echo e($tashkilot->name); ?>  xaqida ma’lumot</h2>

        <a href="<?php echo e(route("tashkilot.index")); ?>" class="button w-24 bg-theme-1 text-white">
            Orqaga
        </a>
        

    </div>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <div class="overflow-x-auto" style="background-color: white;margin-top:30px;border-radius:8px;padding:30px 20px;">
            <table class="table">
                <tbody>
                    <div style="display: flex;justify-content: space-between; border-bottom: 1px solid #e2e8f0; padding-bottom: 20px;">
                        <div style="font-size:18px;font-weight: 400;"><?php echo e($tashkilot->name ."  ". $tashkilot->fish); ?>  xaqida ma’lumot</div>
                        <div style="text-align: end;">
                            <a href="<?php echo e(route('tashkilot.edit',['tashkilot'=>$tashkilot->id])); ?>" class="button w-24 bg-theme-1 text-white" style="margin-right:20px;">
                            Tahrirlash
                            </a>
                            <a href="" class="button w-24 bg-theme-6 text-white">
                                O'chirish
                            </a>
                        </div>
                    </div>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Tashkilot nomi</th>
                            <td class="border-b" ><?php echo e($tashkilot->name); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Tashkilot qisqa nomi massalan</th>
                            <td class="border-b"><?php echo e($tashkilot->name_qisqachasi); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Tashkil etilgan yil</th>
                            <td class="border-b"><?php echo e($tashkilot->tash_yil); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Yuridik manzili</th>
                            <td class="border-b"><?php echo e($tashkilot->yur_manzil); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Viloyat manzili</th>
                            <td class="border-b"><?php echo e($tashkilot->viloyat); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Tuman manzili</th>
                            <td class="border-b"><?php echo e($tashkilot->tuman); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Paoliyat yuritayetgan mahzili</th>
                            <td class="border-b"><?php echo e($tashkilot->paoliyat_manzil); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b"> Telepon nomer</th>
                            <td class="border-b"><?php echo e($tashkilot->phone); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Email</th>
                            <td class="border-b"><?php echo e($tashkilot->email); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Web-sayti</th>
                            <td class="border-b"><?php echo e($tashkilot->web_sayti); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Mulkchilik turi</th>
                            <td class="border-b"><?php echo e($tashkilot->turi); ?></td>
                        </tr>

                        <tr>
                            <th class="whitespace-no-wrap border-b"> Tashkilotni saqlash harajatlarining moliyalashtirish manbasi</th>
                            <td class="border-b"><?php echo e($tashkilot->xarajatlar); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Shtst birligi soni</th>
                            <td class="border-b"><?php echo e($tashkilot->shtat_bir); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Xodimlar soni</th>
                            <td class="border-b"><?php echo e($tashkilot->tash_xodimlar); ?></td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Ilmiy xodimlar soni</th>
                            <td class="border-b"><?php echo e($tashkilot->ilmiy_xodimlar); ?> </td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Boshqariv tuzilmasi</th>
                            <td class="border-b"><?php echo e($tashkilot->boshqariv); ?> </td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">STIR raqami </th>
                            <td class="border-b"><?php echo e($tashkilot->stir_raqami); ?> </td>
                        </tr>
                        <tr>
                            <th class="whitespace-no-wrap border-b">Xizmat ko'rsatuvch bank</th>
                            <td class="border-b"><?php echo e($tashkilot->bank); ?> </td>
                        </tr>
                        
                </tbody>
            </table>
        </div>



        

    </div>





   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Администратор\Desktop\exsel.uz\resources\views/admin/tashkilot/show.blade.php ENDPATH**/ ?>