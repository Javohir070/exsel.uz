<nav class="side-nav">
    <a href="" class="intro-x flex items-center pl-5 pt-4">
        <img width="40px" alt="Midone Tailwind HTML Admin Template" class="w-10" src="/admin/dist/images/logo.png">
        <span class="hidden xl:block text-white text-lg ml-3" style="font-size: 12px; "> Ilmiy tadqiqot muassasalari faoliyat monitoring tizimi </span>
    </a>
    <div class="side-nav__devider my-6"></div>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', ['admin','Xodimlar_uchun_masul','Tashkilot_pasporti_uchun_masul','Ilmiy_faoliyat_uchun_masul'])): ?>
			<a href="" class=" items-center ">
				<img width="" style="text-align: center;margin: 10px auto;width: 70%;" alt="Midone Tailwind HTML Admin Template"  src="<?php echo e(asset('storage/'. auth()->user()->tashkilot->logo)); ?>">
				<span class="hidden xl:block text-white text-lg ml-3" style="font-size: 18px; text-align: center;"> <?php echo e(auth()->user()->tashkilot->name); ?></span>
			</a><br>
    <?php endif; ?>
    <ul>
        <li>
            <a href="<?php echo e(route("home.index")); ?>" class="side-menu side-menu<?php echo e(request()->is('/*') ? '--active':''); ?>" >
                <div class="side-menu__icon"> <i data-feather="home"></i> </div>
                <div class="side-menu__title"> Dashboard </div>
            </a>
        </li>
    <!-- start superadmin -->
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        
        <li>
            <a href="javascript:;" class="side-menu side-menu<?php echo e(request()->is('iqtisodiylar*') ? '--active':''); ?><?php echo e(request()->is('tashkilotrahbarilar*') ? '--active':''); ?><?php echo e(request()->is('tashkilotlar*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="box"></i> </div>
                <div class="side-menu__title">  Tashkilotlar <i data-feather="chevron-down"
                        class="side-menu__sub-icon"></i> </div>
            </a>
            <ul class="<?php echo e(request()->is('iqtisodiylar*') ? 'side-menu__sub-open':''); ?><?php echo e(request()->is('tashkilotrahbarilar*') ? 'side-menu__sub-open':''); ?><?php echo e(request()->is('tashkilotlar*') ? 'side-menu__sub-open':''); ?>">
                
                <li>
                    <a href="<?php echo e(route('tashkilotlar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('tashkilotlar*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title"> Tashkilot pasportilari </div>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route("tashkilotrahbarilar.index")); ?>" class="side-menu side-menu<?php echo e(request()->is('tashkilotrahbarilar*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title">  Tashkilotlar raxbarlari  </div>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('iqtisodiylar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('iqtisodiylar*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title">  Iqtisodiy moliyaviy faoliyatlari   </div>
                    </a>
                </li>

            </ul>
        </li>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        <li>
            <a href="<?php echo e(route("xodim.barchaXodimlar")); ?>" class="side-menu side-menu<?php echo e(request()->is('xodim*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="inbox"></i> </div>
                <div class="side-menu__title"> Xodimlar </div>
            </a>
        </li>
    <?php endif; ?>
    
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        <li>
            <a href="<?php echo e(route('ilmiyloyihalar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('ilmiyloyihalar*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="inbox"></i> </div>
                <div class="side-menu__title"> Ilmiy loyhilalar </div>
            </a>
        </li>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        <li>
            <a href="<?php echo e(route('xujaliklar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('xujaliklar*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="inbox"></i> </div>
                <div class="side-menu__title"> Xujaliklar shartnomalar </div>
            </a>
        </li>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        <li>
            <a href="<?php echo e(route('ilmiydarajalar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('ilmiydarajalar*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="inbox"></i> </div>
                <div class="side-menu__title"> Loyiha bilan taminlangami </div>
            </a>
        </li>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        
        <li>
            <a href="javascript:;" class="side-menu side-menu<?php echo e(request()->is('users*') ? '--active':''); ?><?php echo e(request()->is('permissions*') ? '--active':''); ?><?php echo e(request()->is('roles*') ? '--active':''); ?><?php echo e(request()->is('tashkilot*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="settings"></i> </div>
                <div class="side-menu__title">  Sozlamalar <i data-feather="chevron-down"
                        class="side-menu__sub-icon"></i> </div>
            </a>
            <ul class="<?php echo e(request()->is('users*') ? 'side-menu__sub-open':''); ?><?php echo e(request()->is('permissions*') ? 'side-menu__sub-open':''); ?><?php echo e(request()->is('roles*') ? 'side-menu__sub-open':''); ?><?php echo e(request()->is('tashkilot*') ? 'side-menu__sub-open':''); ?>">

                <li>
                    <a href="<?php echo e(route("tashqoshish.create")); ?>" class="side-menu side-menu<?php echo e(request()->is('tashkilot*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title"> Tashkilot qo'shish </div>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('users.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('users*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title"> Userlar </div>
                    </a>
                </li>

                
                <li>
                    <a href="<?php echo e(route("roles.index")); ?>" class="side-menu side-menu<?php echo e(request()->is('roles*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title"> Rolelar </div>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('permissions.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('permissions*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title">  Permissions  </div>
                    </a>
                </li>
            </ul>
        </li>
    <?php endif; ?>

   <!-- start admin userlar -->
   <?php if (\Illuminate\Support\Facades\Blade::check('role', ['admin','Tashkilot_pasporti_uchun_masul'])): ?>
        <li>
            <a href="javascript:;" class="side-menu side-menu<?php echo e(request()->is('tashkilot*') ? '--active':''); ?><?php echo e(request()->is('iqtisodiy*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="box"></i> </div>
                <div class="side-menu__title">  Tashkilot pasporti  <i data-feather="chevron-down"
                        class="side-menu__sub-icon"></i> </div>
            </a>
            <ul class="<?php echo e(request()->is('tashkilot*') ? 'side-menu__sub-open':''); ?><?php echo e(request()->is('iqtisodiy*') ? 'side-menu__sub-open':''); ?>">
                <li>
                    <a href="<?php echo e(route('tashkilot.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('tashkilot*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title"> Tashkilot pasportini tuldirish </div>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route("iqtisodiy.index")); ?>" class="side-menu side-menu<?php echo e(request()->is('iqtisodiy*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title">  Iqtisodiy moliyaviy faoliyat  </div>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route("tashkilotrahbari.index")); ?>" class="side-menu side-menu<?php echo e(request()->is('tashkilotrahbari*') ? '--active':''); ?>">
                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                        <div class="side-menu__title"> Tashkilot rahbari </div>
                    </a>
                </li>
            </ul>
        </li>
    <?php endif; ?>
   
    <?php if (\Illuminate\Support\Facades\Blade::check('role', ['admin','Xodimlar_uchun_masul'])): ?>
        <li>
            <a href="<?php echo e(route('xodimlar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('xodimlar*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="file-text"></i> </div>
                <div class="side-menu__title"> Xodimlar </div>
            </a>
        </li>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', ['admin','Ilmiy_faoliyat_uchun_masul'])): ?>
        <li>
            <a href="<?php echo e(route("ilmiyloyiha.index")); ?>" class="side-menu side-menu<?php echo e(request()->is('ilmiyloyiha*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="file-text"></i> </div>
                <div class="side-menu__title"> Ilmiy loyihalalar </div>
            </a>
        </li>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', ['admin','Ilmiy_faoliyat_uchun_masul'])): ?>
    <li>
        <a href="<?php echo e(route("xujalik.index")); ?>" class="side-menu side-menu<?php echo e(request()->is('xujalik*') ? '--active':''); ?>">
            <div class="side-menu__icon"> <i data-feather="file-text"></i> </div>
            <div class="side-menu__title"> Xo'jalik loyihalalar </div>
        </a>
    </li>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('role', ['admin','Ilmiy_faoliyat_uchun_masul'])): ?>
    <li>
        <a href="<?php echo e(route("ilmiydaraja.index")); ?>" class="side-menu side-menu<?php echo e(request()->is('ilmiydaraja*') ? '--active':''); ?>">
            <div class="side-menu__icon"> <i data-feather="file-text"></i> </div>
            <div class="side-menu__title"> Ilmiy loyiha bilan taminlangami </div>
        </a>
    </li>
    <?php endif; ?>
    <!-- end admin -->
    <div class="side-nav__devider my-6"></div>
		<li>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['style' => 'color: white;padding: 8px;margin-left: 16px;','class' => 'side-menu flex items-center block p-2 transition duration-300 ease-in-out hover:bg-theme-1 rounded-md','href' => route('logout'),'onclick' => 'event.preventDefault();
                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'color: white;padding: 8px;margin-left: 16px;','class' => 'side-menu flex items-center block p-2 transition duration-300 ease-in-out hover:bg-theme-1 rounded-md','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                this.closest(\'form\').submit();']); ?>
                <div class="side-menu__icon"> <i data-feather="toggle-right" class="w-4 h-4 mr-2"></i> </div>
                Chiqish
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
        </form>
    </li>
    </ul>
</nav>










<!-- <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        <li>
            <a href="<?php echo e(route('tashkilotlar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('tashkilotlar*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="inbox"></i> </div>
                <div class="side-menu__title"> Tashkilotlar </div>
            </a>
        </li>
    <?php endif; ?>  -->
    
    <!-- <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        <li>
            <a href="<?php echo e(route('tashkilotrahbarilar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('tashkilotrahbarilar*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="inbox"></i> </div>
                <div class="side-menu__title"> Tashkilotlar raxbarlar </div>
            </a>
        </li>
    <?php endif; ?>  -->
    <!-- <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
        <li>
            <a href="<?php echo e(route('iqtisodiylar.index')); ?>" class="side-menu side-menu<?php echo e(request()->is('iqtisodiylar*') ? '--active':''); ?>">
                <div class="side-menu__icon"> <i data-feather="inbox"></i> </div>
                <div class="side-menu__title">Iqtisodiy Moliyaviy faoliyat </div>
            </a>
        </li>
    <?php endif; ?>  --><?php /**PATH C:\Users\user\Desktop\manitoring\exsel.uz\resources\views/layouts/nav-admin.blade.php ENDPATH**/ ?>