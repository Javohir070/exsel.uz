<?php $__env->startSection("content"); ?>
<div class="flex justify-between align-center mt-10">

    <h2 class="intro-y text-lg font-medium">Users qo'shish </h2>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create user')): ?>
        <a href="<?php echo e(url('users')); ?>" class="button w-24 bg-theme-1 text-white">
            Orqaga
        </a>
    <?php endif; ?>
</div>


<div class="intro-y col-span-12 flex flex-wrap sm:flex-no-wrap items-center mt-2" style="background: white;
    padding: 20px 20px;
    border-radius: 20px">
    <?php if($errors->any()): ?>
        <ul class="alert alert-warning">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <div class="w-full mt-3 sm:mt-0 sm:ml-auto md:ml-0">
        <form id="science-paper-create-form" method="POST" action="<?php echo e(url('users')); ?>"
            class="validate-form" enctype="multipart/form-data" novalidate="novalidate">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-12 gap-2">
                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super-admin')): ?>
                    <div class="w-full col-span-6">
                        <label class="flex flex-col sm:flex-row"> <span
                        class="mt-1 mr-1 sm:mt-0 text-xs text-red-600">*</span>Name
                        </label>
                        <input type="text" name="name" class="input w-full border mt-2" >
                    </div>
                <?php endif; ?>
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                    <div class="w-full col-span-6">
                        <label class="flex flex-col sm:flex-row"> <span
                                class="mt-1 mr-1 sm:mt-0 text-xs text-red-600">*</span> Xodimlar
                        </label>
                        <select name="name" class="input border w-full mt-2" >
                            <option value=""> Xodimlar tanlash</option>
                            <?php $__currentLoopData = $xodimlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->fish); ?>"><?php echo e($role->fish); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    
                    <div class="w-full col-span-6">
                        <label class="flex flex-col sm:flex-row"> <span
                        class="mt-1 mr-1 sm:mt-0 text-xs text-red-600">*</span>Email
                        </label>
                        <input type="email" name="email" class="input w-full border mt-2" required="">
                    </div>

                    <div class="w-full col-span-6">
                        <label class="flex flex-col sm:flex-row"> <span
                        class="mt-1 mr-1 sm:mt-0 text-xs text-red-600">*</span>Password
                        </label>
                        <input type="text" name="password" class="input w-full border mt-2" required="">
                    </div>

                    <div class="w-full col-span-6">
                        <label class="flex flex-col sm:flex-row"> <span
                                class="mt-1 mr-1 sm:mt-0 text-xs text-red-600">*</span> Role
                        </label>
                        <select name="roles[]" class="input border w-full mt-2" >
                            <option value=""> Role tanlash</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role); ?>"><?php echo e($role); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="w-full col-span-6">
                        <label class="flex flex-col sm:flex-row"> <span
                                class="mt-1 mr-1 sm:mt-0 text-xs text-red-600">*</span> Tashkilotni tanlag
                        </label>
                        <select name="tashkilot_id" class="input border w-full mt-2">
                            <?php $__currentLoopData = $tashkilots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tashkilot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tashkilot->id); ?>"><?php echo e($tashkilot->name_qisqachasi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    

                    
            </div><br>
        </form><br>
        <div class="px-5 pb-5 text-center">
            <a href="#"  class="button delete-cancel w-32 border text-gray-700 mr-1">
                Bekor qilish
            </a>
            <button type="submit" form="science-paper-create-form" class="update-confirm button w-24 bg-theme-1 text-white">
                Qo'shish
            </button>
        </div>
    </div>
</div><br>














<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\manitoring\exsel.uz\resources\views/role-permission/user/create.blade.php ENDPATH**/ ?>