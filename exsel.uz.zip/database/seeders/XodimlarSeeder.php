<?php

namespace Database\Seeders;

use App\Models\Xodimlar;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class XodimlarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Xodimlar::factory()->count(200)->create();
    }
}
