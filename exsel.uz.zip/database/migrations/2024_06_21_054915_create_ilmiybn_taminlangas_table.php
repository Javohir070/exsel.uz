<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ilmiybn_taminlangas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('tashkilot_id')->constrained()->cascadeOnDelete();
            $table->foreignId('umumiyyil_id')->constrained()->cascadeOnDelete();
            $table->foreignId('yillar_id')->constrained()->cascadeOnDelete();
            $table->string("xodimlar_jami");
            $table->string("ilmiy_xodimlar");
            $table->string("name");
            $table->string("turi");
            $table->string("moliyal_jami");
            $table->string("xodimganisbat_jami");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ilmiybn_taminlangas');
    }
};
