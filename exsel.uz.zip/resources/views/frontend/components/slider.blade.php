<section class="container">
    <div class="our-courses" id="courses">
        <div class="owl-courses-items owl-carousel">
            <div class="items ">
                <img src="./frontent/img/1652980696.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="items">
                <img src="./frontent/img/1652980705.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="items">
                <img src="./frontent/img/1652980816.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="items">
                <img src="./frontent/img/1652981575.jpg" class="d-block w-100" alt="...">
            </div>
        </div>
    </div>
</section>